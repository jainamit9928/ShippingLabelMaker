import React from 'react';
import {render} from 'react-dom';
import {BrowserRouter as Router, Route, Link} from "react-router-dom";

class ProgressBar extends React.Component {
    constructor(props){
        super(props);
        this.state= {
            steps : ['A','B','C','D']
        }
    }

    render() {

        return (
            <div className="btn-group">
                {this.state.steps.map((value,index) => <Steps value={value} className="btn btn-default" index={index} key={index} counter={this.props.steps}/>)}
                <button className="btn btn-default" onClick={this.back}>Back</button>
                <button className="btn btn-default" onClick={this.proceed}>Proceed</button>

            </div>
        );
    }
}


class Steps extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            stepClass : {
                    backgroundColor : '#fff',
                    borderRadius : '5px',
                    padding : '1em',
                    margin : '1em',
                    border: 0
                }
        }
    }
    componentWillMount(){
        if(this.props.index==0){
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { border: '5px solid red' })});
        }

    }
    componentWillReceiveProps(nextProps){
        if (nextProps.index === nextProps.counter){
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { border: '5px solid red' })});
        }
        else{
            this.setState({stepClass : Object.assign({}, this.state.stepClass, { border: '0' })});
        }
    }
    render() {

        return (
            <div style={this.state.stepClass}>
                {this.props.value}
            </div>
        );
    }
}

export default ProgressBar;
