import React from 'react'
import { Route, Switch} from 'react-router-dom'
import HomeContainer from '../../container/home'
import ShippingLabelMakerContainer from '../../container/shippingDetails'

const Routes = () => (
    <div>
        <Switch>
            <Route exact path='/' component={ HomeContainer }/>
            <Route exact path='/shippingDetail' component={ ShippingLabelMakerContainer }/>
            <Route component={HomeContainer}/>
        </Switch>
    </div>
)
export default Routes
