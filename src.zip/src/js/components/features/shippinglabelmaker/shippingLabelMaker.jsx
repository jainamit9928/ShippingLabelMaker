import React from 'react'
import Loader from 'react-loader'
import Widget from '../../core/widget'
import PropTypes from 'prop-types'
export default class ShippingLabelMaker extends React.PureComponent {

   constructor(props) {
        super(props);
        this.state = {
            shippingDetail: {},
            hasError: false,
            steps:null
        }
        //this.onOpenModal = this.onOpenModal.bind(this)
        this.onChange = this.onChange.bind(this)
        this.onUpdate = this.onUpdate.bind(this)
        this.goForwad =  this.goForwad.bind(this)
        this.goBack = this.goForwad.bind(this)
        this.validateForm = this.validateForm.bind(this)
    }

    componentDidMount() {
        console.log("maker",this.props.shippingDetail)
        this.setState({ shippingDetail: Object.assign({}, this.props.shippingDetail ) ,steps:this.props.steps } )
        console.log("state",this.state.shippingDetail)
    }

    onUpdate() {
       this.props.actions.setShippingDetail(this.state.shippingDetail)
       this.goForwad()
    }
    goForwad(){
        this.setState({ steps: this.state.steps + 1  } , function(){
             this.props.actions.setSteps(this.state.steps)
        } )
    }
    goBack(){
        this.setState({ steps: this.state.steps - 1  }, function(){
            console.log(this.state.steps)
             this.props.actions.setSteps(this.state.steps)
        } )
    }
    validateForm() {
        let flag = (_.isEmpty(this.state.techie.name)  || _.isEmpty(this.state.techie.title) 
                    ||  _.isEmpty(this.state.techie.organisation)  || _.isEmpty(this.state.techie.country) )
                    
       flag ?this.setState({ hasError: true })
       :
       this.setState({ hasError: false })
    }
    onChange(e) {
        const type = e.target.className;
        let temp;
        if (type.includes("receiver")){
            temp = this.state.shippingDetail.receiverDetails
        }
        else if(type == "sender"){
            temp = this.state.shippingDetail.senderDetails
        }
        else if(type == "weight"){
            temp = this.state.shippingDetail.weight
        }
        else if(type == "shippingOption"){
            temp = this.state.shippingDetail.shippingOption
        }
        const key = e.target.name
        console.log(temp)
        temp[key] = e.target.value
        this.setState({ shippingDetail: Object.assign({},this.state.shippingDetail, temp) })
        //this.validateForm()
    }
  
    render() {
        console.log(this.state.shippingDetail)
        return (
              Object.keys(this.state.shippingDetail).length > 0 && (
            <div>             
                 <Widget shippingDetail ={ this.state.shippingDetail } hasError ={ this.state.hasError } steps ={ this.state.steps } onChange = { this.onChange } onUpdate ={ this.onUpdate } goForwad={ this.goForwad } goBack = { this.goBack }/>
            </div>
        )
        )
    }
}

ShippingLabelMaker.propTypes = {
    actions: PropTypes.object.isRequired,
    shippingDetail: PropTypes.object.isRequired,
}
