import React from 'react'
import Routes from './components/core/router'
import NavBar from './components/core/navbar'
import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from 'redux'
import shippingLabelMakerReducer from './reducers'
import { rootSaga } from './sagas/saga.js'
import createSagaMiddleware from 'redux-saga'
import ReactDOM from 'react-dom'
import { BrowserRouter as Router, browserHistory } from 'react-router-dom'
import '../css/bootstrap.css'
import '../css/app.less'
import Footer from './components/core/footer'
import { API_URL } from './constants/constants'

const sagaMiddleware = createSagaMiddleware();
const store = createStore(shippingLabelMakerReducer, applyMiddleware(sagaMiddleware));
sagaMiddleware.run(rootSaga);
const App = () => (
    <div>
     <ul className='topnav'>
            <img className='avatar' src={ API_URL+'/techfinder.png' }/>
        </ul>
        <nav>
          <NavBar/>
        </nav>
    <div className='row'>
      <div className='col-md-12'>
        <main>
          <Provider store={ store }>
          <Routes/>
          </Provider>
        </main>
      </div>
   </div>
   <Footer/>
   </div>
)
ReactDOM.render(
    <Router history={ browserHistory }>
      <App/>
    </Router>
    , document.getElementById('container')
)
